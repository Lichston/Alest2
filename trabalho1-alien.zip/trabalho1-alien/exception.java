
public class exception {

}
